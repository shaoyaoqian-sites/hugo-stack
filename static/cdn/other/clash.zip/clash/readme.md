


文件夹中的`clash`为可执行程序，`yesha.yaml`为机场提供的配置文件。初次使用需先赋予可执行权限:
```bash
chmod +x ./clash
```
然后启动clash:
```bash 
./clash -d . -f yesha.yaml
```
在终端设置代理地址:
```bash
export https_proxy=http://127.0.0.1:7890 http_proxy=http://127.0.0.1:7890 all_proxy=socks5://127.0.0.1:7890
```
在此终端中执行git, spack等命令需联网时会自动连接外网。docker需要进一步设置。
